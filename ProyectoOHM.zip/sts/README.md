iw
==

Material para Tecnologías Web

Este proyecto está pensado para ejecutarse sobre Spring STS v3.6.1. 
Parte de la base de la plantilla "Spring MVC Project", e irá añadiendo aspectos de la asignatura a medida que se vayan incorporando.

Cualquier comentario (issue) ó, mejor todavía, "pull request" será bienvenido.
