package es.fdi.iw.model;

public enum ModerationCategory {
	File,
	Post,
	Thread
}
