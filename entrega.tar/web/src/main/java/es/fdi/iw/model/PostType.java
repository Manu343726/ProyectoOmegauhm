package es.fdi.iw.model;

public enum PostType {
	QUESTION, ANSWER
}
