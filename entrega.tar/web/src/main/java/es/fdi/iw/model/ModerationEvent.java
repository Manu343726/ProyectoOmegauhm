package es.fdi.iw.model;

public enum ModerationEvent {
	NewFile,
	NewThread,
	NewPost,
	EditFile,
	EditPost,
	DeleteFile
}
